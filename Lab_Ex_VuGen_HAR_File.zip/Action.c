Action()
{

	lr_think_time(5);
	
	lr_start_transaction("Home_Page");
	
	web_url("home.html", 
		"URL=https://www.hpe.com/us/en/home.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/etc/clientlibs/hpeweb/css/hpe-global.css", ENDITEM, 
		"Url=/content/dam/hpe/global/base/imageOnly/HPE_log_left_wht.png", "Referer=", ENDITEM, 
		"Url=/content/dam/hpe/shared-publishing/base/homepage/imageOnly/Homepage_33-33-33-Shop_2x-md.svg", ENDITEM, 
		"Url=/content/dam/hpe/shared-publishing/base/homepage/imageOnly/Homepage_33-33-33-Communities_2x-md.svg", ENDITEM, 
		"Url=/content/dam/hpe/shared-publishing/base/homepage/imageOnly/Homepage_33-33-33-Support_2x-md.svg", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/js/hpe.dll.libs.js", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/js/hpe.general.0331a048e05a8db2e776.js", ENDITEM, 
		"Url=https://art.itcs.hpe.com/api/personalization/v3/poi?mcid=12814466200295817263768634506454146261", ENDITEM, 
		"Url=/content/dam/hpe/shared-publishing/base/homepage/marqueeLarge/SERVERS_MARQUEE_75-Image-Left-2x_md.jpg/jcr:content/renditions/image-1x-sm", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/fonts/Metric-Light.woff", "Referer=https://www.hpe.com/etc/clientlibs/hpeweb/css/hpe-global.css", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/fonts/hpe-glyphicons.woff", "Referer=https://www.hpe.com/etc/clientlibs/hpeweb/css/hpe-global.css", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/fonts/Metric-Regular.woff", "Referer=https://www.hpe.com/etc/clientlibs/hpeweb/css/hpe-global.css", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/fonts/Metric-Semibold.woff", "Referer=https://www.hpe.com/etc/clientlibs/hpeweb/css/hpe-global.css", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/images/sprite/sprite-sprite.png", "Referer=", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/fonts/Metric-Medium.woff", "Referer=https://www.hpe.com/etc/clientlibs/hpeweb/css/hpe-global.css", ENDITEM, 
		"Url=/etc/clientlibs/hpeweb/images/loader.gif", "Referer=", ENDITEM, 
		"Url=https://smetrics.hpe.com/b/ss/hpcstsg/1/JS-1.6.3/s25877067104649?AQB=1&ndh=1&pf=1&t=6%2F3%2F2017%2015%3A8%3A38%204%20240&sdid=77395BD3D9BC3405-006883345226522D&mid=12814466200295817263768634506454146261&aamlh=7&ce=UTF-8&ns=hpcorp&pageName=home&g=https%3A%2F%2Fwww.hpe.com%2Fus%2Fen%2Fhome.html&cc=USD&ch=home&server=www.hpe.com&aamb=NRX38WO0n5BH8Th-nqAG_A&v1=us%3Aen&h1=home&c5=corporate&c7=us%3Aen&v11=bkguid%3A%2FSgk3Q99999CS5BR&c12=R11936&c13=hpcstsg&c14="
		"mcid%3A12814466200295817263768634506454146261&c20=gateway&c22=ut4.37.201704061636&v23=corporate&v25=Campaign%3DHPE-Pers-HomePocV3-POI-US-201702%3ARecipe%3DServers&v27=Campaign%3DHPE-Pers-HomePocV3-POI-US-201702%3ARecipe%3DServers&c45=tid%3A1491505716242&v47=api%3Atrue%7Cpoi%3Aservers%7Clevel%3Avisitor%7Cec%3A0%7Ct%3A141%7CttMETA%3Atrue&c49=https%3A%2F%2Fwww.hpe.com%2Fus%2Fen%2Fhome.html&c50=D%3Dg&v55=home&c59=us%3Aen%3A1160446308%3Ahome&c64=marketing&v69=home&c73=home&v97=1170318180524434.63&s="
		"1536x864&c=24&j=1.6&v=N&k=Y&bw=982&bh=759&AQE=1", ENDITEM, 
		"Url=/content/dam/hpe/shared-publishing/base/homepage/hybridRouter/Homepage_Hybrid-Router-MedWall-03-23_2x-md.jpg/jcr:content/renditions/image-1x-sm", ENDITEM, 
		"Url=/content/dam/hpe/shared-publishing/base/homepage/hybridRouter/Homepage_Hybrid-Router-MedWall-2_2x-md.jpg/jcr:content/renditions/image-1x-sm", ENDITEM, 
		"Url=/content/dam/hpe/shared-publishing/base/homepage/hybridRouter/Homepage_Hybrid-Router-MedWall-3_2x-md.jpg/jcr:content/renditions/image-1x-sm", ENDITEM, 
		"Url=/services/hpe/reactive-chat-status?portid=8F2990FB-B1C1-487C-8AD5-A04A0ADE2F93&questid=456B2114-9DBC-4008-8930-E51A898E7AC0", ENDITEM, 
		"Url=/content/dam/hpe/localizedImages/en/moxie-chat-on.png", ENDITEM, 
		"Url=https://smetrics.hpe.com/b/ss/hpcstsg/1/JS-1.6.3/s27021307296315?AQB=1&ndh=1&pf=1&t=6%2F3%2F2017%2015%3A8%3A46%204%20240&mid=12814466200295817263768634506454146261&aamlh=7&ce=UTF-8&ns=hpcorp&pageName=home&g=https%3A%2F%2Fwww.hpe.com%2Fus%2Fen%2Fhome.html&cc=USD&ch=home&v1=us%3Aen&c5=corporate&c7=us%3Aen&c12=R11936&c13=hpcstsg&c14=mcid%3A12814466200295817263768634506454146261&v23=corporate&c45=tid%3A1491505726140&v47="
		"api%3Atrue%7Cpoi%3Aservers%7Clevel%3Avisitor%7Cec%3A0%7Ct%3A141%7CttMETA%3Atrue&c64=marketing&c69=home&v75=home&pe=lnk_o&pev2=mainnav%3Acontact%20us%3Amain&s=1536x864&c=24&j=1.6&v=N&k=Y&bw=982&bh=759&AQE=1", ENDITEM, 
		LAST);

	lr_end_transaction("Home_Page", LR_AUTO);

	
	return 0;
}